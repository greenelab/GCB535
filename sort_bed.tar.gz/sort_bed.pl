#!/usr/bin/perl -w

if (scalar(@ARGV) == 2) {
    $bedfile = shift(@ARGV);
    $outfile = shift(@ARGV);
} else {
    print "usage: %> sort_bed.pl myfile.bed outputfile\n";
    exit();
}

for ($i=1; $i<=25; $i++) {
    if ($i == 23) {
	$e = "M";
    } elsif ($i == 24) {
	$e = "X";
    } elsif ($i == 25) {
	$e = "Y";
    } else {
	$e = $i;
    }

    print STDERR "$e\n";
    if ($i == 1) {
	system "fgrep -w \"chr@{[$e]}\" <@{[$bedfile]} | sort -k2,2n >@{[$outfile]}";
    } else {
	system "fgrep -w \"chr@{[$e]}\" <@{[$bedfile]} | sort -k2,2n >>@{[$outfile]}";
    }

}
